#!/bin/bash
set -e

# LFS cross-compilation friendly build script for Bash 5.2.37
./configure   --prefix=/usr   --bindir=/bin   --docdir=/usr/share/doc/bash-5.2.37   --without-bash-malloc   --with-installed-readline

make -j$(nproc)

make tests

make DESTDIR=$LFS install

mv $LFS/bin/bash $LFS/bin/bash-old
cp bash $LFS/bin/bash
